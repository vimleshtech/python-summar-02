
n =110

if n%2 ==0:#if no is divided by 2
    print('even no')
    print(1)
    
else:
    print('odd no')
    
