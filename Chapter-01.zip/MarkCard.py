
# wap to input from user

sid = input('enter data :')
name = input('enter name ')
hs = input('enter mark in hindi ')
es = input('ente mark in eng ')

print('id is ',sid)
print('name is ',name)


total = int( hs) + int(es) #int() is function to convert/type cast from str to int


print('total ',total)




