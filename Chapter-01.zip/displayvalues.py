roll = input ('enter data :')
name = input ('enter data :')
marks = input ('enter data :')
phone = input ('enter data :')

print ('roll no is ',roll)
print ('marks is ',marks)
print ('name is',name)
print ('phone is',phone)
