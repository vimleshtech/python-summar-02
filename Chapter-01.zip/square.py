n =int( input('enter a number :'))
square = n*n

print ('square ',square)
