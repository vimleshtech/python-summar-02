roll = input('enter roll no')
sname = input('enter name')
hmarks = input ('enter marks in hindi')
emarks = input ('enter marks in english')
smarks = input ('enter marks in science')
mmarks = input ('enter marks in maths')
dmarks = input ('enter marks in drawing')

print ('roll no is', roll)
print ('sname is', sname)

sum = int(hmarks) + int(emarks) + int(smarks) + int(mmarks) + int(dmarks)

print ('sum',sum)

avg = sum/5
print ('avg',avg)
