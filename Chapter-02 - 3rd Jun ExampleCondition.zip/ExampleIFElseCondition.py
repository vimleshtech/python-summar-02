
amt = int(input('enter sales amt :'))

#if condition 
tax = 0
if amt>1000:
     tax = amt*.18 #18% tax of amt

else:
     tax = amt*.05
     
total = amt+tax
print(total)

