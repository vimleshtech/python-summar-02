#WAP to show greater no from three inputs
a = int(input('enter number :'))
b = int(input('enter number :'))
c = int(input('enter number :'))

if a>b and a>c:   #and : if both condition match then true otherwise false 
     print(a,' is greater ')
elif b>a and b>c:
     print(b,' is greater')
else:
     print(c,' c is greater')

     
##nestd if else
if a>b:
     if a>c:
          print('a is greater')
     else:
          print('c is greater')
else:
     if b>c:
          print('b is greater')
     else:
          print('c is greater')




          
