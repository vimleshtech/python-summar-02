a = ['Mon','Tue','Wed','Thu','Fri']

day = input('today day name :')

if day in a:
     print('working days ')
else:
     print("entry is allowed , today's is holiday")
     

