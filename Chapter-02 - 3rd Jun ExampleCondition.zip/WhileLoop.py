#while
#in asc
i =1
while i<10: #print from 1 to <10
     #print(i) #print and new line
     print(i,end='\t')
     i+=1
     

print() #new line 

#print in rev
i  =10
while i>0:
     print(i)
     i-=1

#print all odd numbers between 1 to 30
i =1
while i<=30:
     print(i)
     i+=2

#WAP to get sum of all even and odd numbers between 1 to 100
i =1
se =0
so = 0
while i<=100:
     if i% 2 ==0:
          se= se+i
          #print(i, 'even ')
     else:
          so = so + i
          #print(i,' odd')
          
          
          
     i+=1


print('sum of all even no ',se)
print('sum of all odd no. ',so)


#WAP to print table of given no
t = int(input('enter num :'))

i = 1 #init 
while i<=10: #condition 

     #print(t*i)
     print(t,'*',i,'=',t*i)
     
     i=i+1 #steps 
     

     



     
