#for loop
#range(10)  # from  0 to <10
#range(0,10)  # from 0 to <10
#range(0,10,1) # from 0 to <10, default incrementer is 1

for x in range(10): #assign value from right to left one by one (in iteration)
     print(x)
#
for x in range(1,10,2): # from 1 3 5 7 9
     print(x)

#in rev
for i in range(10,0,-1): #fro 10  to >0
     print(i)
     
     
     


