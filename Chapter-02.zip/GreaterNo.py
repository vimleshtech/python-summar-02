#and
a = input('enter a')
b =input('enter b ')
c =input('enter c ')

#default input type is str, so we need to type cast
#print(type(a))

a = int(a)
b = int(b)
c = int(c)


if a>b and a>c:
     print('a is gt')
elif b>a and b>c:
     print('b is gt')
else:
     print('c is gt')

#nested if else
if a>b:
     if a>c:
          print('a is gt')
     else:
          print('c is gt')
else:
     if b>c:
          print('b is gt')
     else:
          print('c is gt')
     
