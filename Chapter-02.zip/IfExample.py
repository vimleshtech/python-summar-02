amt = 100

#wap to add GST
#Example -1 
tax=0
#if condition 
if amt > 1000:
 tax = amt *.18

total = amt+tax
print(total)


#Example - 2
tax =0
if amt>1000:
     tax = amt *.18
else:
     tax = amt*.05

total = amt+tax
print(total)


#Example - 2
amt = 30000
tax =0
if amt>5000:
     tax = amt *.27
elif amt > 1000:
     tax = amt*.12
elif amt> 500:
     tax = amt*.10
else:
     tax = amt*.05

total = amt+tax
print(total)











     

     
