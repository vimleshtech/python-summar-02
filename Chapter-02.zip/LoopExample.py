
#while loop
i =1#init

while i<10: #condition
     #print(i) #print and change line /new line
     print(i,end=',') #print in same line
     i+=1 # i=i+1

     

#print in rev
i =10
while i>0:
     print(i)
     i-=1
     
#for
for x in range(1,10): #from 1 to <10 , default incrementer is 1 (init,con,increement/de)
     print(x)

#in rev
for x in range(10,0,-1):
     print(x)


##wap to get sum of all even and odd numbers between two given range
s = int(input('enter start from :'))
d = int(input('enter end :'))

se = 0
so =0

for i in range(s,d+1):
     if i% 2 ==0:
          se +=i
     else:
          so+=i

print('sum of all even no :',se)
print('sum of all odd no :',so)





          



     




     








     

     
