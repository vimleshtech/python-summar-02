
a = input('enter a')

b = a.split(' ')
print(b)

