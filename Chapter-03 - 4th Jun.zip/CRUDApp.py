
data =[]

while True: #infinite
     ch = input('enter 1 for add 2 for read 3 for update 4 for delete 0 for exit ')
     if ch=='1':
          print('in add')
          x = input('enter val :')
          data.append(x)
                
     elif ch=='2':
          print('in read')
          print(data)


     elif ch=='3':
          print('in update')
          '''
          d = input('enter index :')
          d = int(d)

          nd = input('enter new value :')
          data[d] =nd
          '''
          i =0
          d = input('enter value :')
          
          while i<len(data):
               if d == data[i]:
                    nd = input('enter new value :')
                    data[i] =nd
               i=i+1
                    
               
               
                    

     elif ch=='4':
          print('in delete')
          d = input('etner data to remove :')
          if d in data:  #is d(given value) exist in lsit or not
               data.remove(d)
          else:
               print('given value is not found')
               
          

     elif ch =='0':
          break    #to stop or terminate the loop
     else:
          print('invalid input, try again!!!')
          


     
     
