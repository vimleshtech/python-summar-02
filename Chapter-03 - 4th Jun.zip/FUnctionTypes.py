#function example
#no argument no return
def fun1():
     print('this file contains add, sub,mul function')


#no argument with return
def get_data():
     a = input('enter data :')
     b = input('enter data :')
     return a,b

#argument with no return
def add(a,b):
     c =a+b
     print('sum of two values :',c)
     

#argument with return
def mul(a,b):
     c =a*b
     return c

fun1()
x,y =  get_data()
print(x+y)

add(44,5)
add(55,6222)

o = mul(11,33)
print(o)
add(o,100)

     
     

