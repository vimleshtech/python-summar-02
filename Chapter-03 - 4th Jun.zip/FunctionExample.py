def test():
     print('test function ...')
     print('no argument and no return function')

def add():
 a =33
 b =44
 c =a+b
 print('sum of two numebers :',c)
def mul():
     a =33
     b =44
     c =a*b
     print(c)

#call/invoke/execute the  function
test()
#add()
mul()

     
     
