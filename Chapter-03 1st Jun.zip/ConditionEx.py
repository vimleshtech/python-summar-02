
sal = int( input('enter basic sal :'))

if sal>500000:
    print('taxable income')

    

#if else
if sal>500000:
    print('taxable income')
else:
    print('non taxable  ')




##if elif elif ....else
if sal>500000:
    print('taxable income')
elif sal >44555:
    print('2nd slab taxable  ')
elif sal>4666:
    print('3rd slab ')

else:
    print('else')




    

    

    
