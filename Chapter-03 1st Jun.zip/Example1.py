
eid = int( input('enter eid :'))
ename =  input('enter name :')
sal = int( input('enter basic sal :'))




'''
#type casting

eid = int(eid)
'''


#print(type(eid))


hra = sal*.40
da = sal*.10
msal = sal+hra+da
ysal = msal*12


print('employee id is ',eid)
print('employee name is ',ename)
print('employee msal is ',msal)
print('employee ysal is ',ysal)






