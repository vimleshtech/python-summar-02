s = input('enter string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.count('a'))
print(len(s))
print(s.split(' '))
print(list(s))


print(s.isupper())

print(s.islower())

