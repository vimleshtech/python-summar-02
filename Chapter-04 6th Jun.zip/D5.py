data= []

for x in range(0,10): #from 0 to <10 ( 10 times)
     n  = int(input('enter data :'))
     data.append(n)


#data= [111,222,3,34,5,3,3,3,2,2,3,45]
     
a = sum(data)/10 #return average
#a = 78

for d in data:  #iterate list item one by one
     if d > a:
          print(d)
          


     

     
     
     
