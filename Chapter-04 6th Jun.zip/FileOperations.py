f= open(r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-1stJun\Chapter-03.txt')

#WAP to get row count
#len is inbuil to of list
d = f.readlines()
print('row count :',len(d))

#WAP to get word count
#example:
s ="this is python code"
print(len(s)) #no of chars (inculding space)
#word count
o = s.split(' ')  #break string by space, default sperator is space
print(o)

print('word count :',len(o))


#get word count from file
#get particular word count /search given word in file
wc = 0
pwc = 0
for r in d:
     o = r.split(' ')
     #print(len(o))
     wc=wc+len(o)

     for w in o:
          if w =='is':
               pwc+=1
               
     

print('no of words in a file :',wc)
print('count of is ',pwc)





     
     
     













