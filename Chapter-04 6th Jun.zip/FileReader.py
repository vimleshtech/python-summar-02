#file reader

f= open(r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-1stJun\Chapter-03.txt')
#print(f.read())

#read first line
#print(f.readline())
#print(f.readline())
#print(f.readline())
#print(f.readline())


d = f.readlines()
print(d)
print(type(d))



#read every item using for loop
for i in range(1,10): #from 1 index (2 row ) to 9th index (10th row)
     print(d[i]) #row by index

#read every item one by one
for r in d: #r is not an index , r is new variable which will take data from d
     print(r)
     
     
     
     
     







