def write_to_file():
     f = open(r'emp.txt','w') #create new file if not exist , overwrite the file if exist
     for i in range(0,5):
          d = input('enter string :')
          f.write(d)
          f.write('\n')
          
     f.close()

def read_from_file():
     f = open(r'emp.txt','r')
     print(f.read())
     f.close()
     


def gender_wise_count():
     f = open(r'emp.txt','r')
     d = f.readlines()
     mc =0
     fc = 0
     for r in d:
          c = r.split(',')
          if c[2] =='male':
               mc+=1
          elif c[2] =='female':
               fc+=1
               
     print('male count :',mc)
     print('femlae count :',fc)
          
     


#call to function 
#write_to_file()
read_from_file()
gender_wise_count()

     
     
