
n = int(input('eter data :'))
d = int(input('eter data :'))


try:
     #div
     if d<0:
          msg = ZeroDivisionError('divisor cannot be less than 0')
          raise msg
     
     o = n/d
     print(o)

except NameError as e:
     print(e)
except ZeroDivisionError as er:
     print(er)
     
except:
     print('there is some error ')
     #pass
finally:
     print('end of the code')
     

#addition 
o  = n+d
print(o)



