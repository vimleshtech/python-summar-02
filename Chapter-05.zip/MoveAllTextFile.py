import os 
import shutil as s 

src =r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-1stJun'
f = os.listdir(src)

for p in f:
     
     if p.endswith('.txt'):
          s.move(p,r'C:\Users\vkumar15\Desktop\out')
          
          
          
          
     

