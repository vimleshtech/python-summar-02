
f = open(r'emp.txt','r')
f.readline()

d = f.readlines() #read all data from file

country= []

for r in d:
     c = r.split(',')
     if c[4] not in country:
          country.append(c[4])

#list of unique country in list (country)
for c in country:
     c = c.replace('\n','')
     w = open(c+'.txt','w')
     for r in d:
          col = r.split(',')
          if col[4].replace('\n','') == c:
               w.write(r)


     w.close()
     
     
     
     
     
     

