import os

src =r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-1stJun'
f = os.listdir(src)
print(f)

w = open('output.txt','w')

for p in f:
     
     if p.endswith('.txt'):
          #print(p)
          r = open(src+'\\'+p)
          w.write(r.read())
          w.write('-----------------------'+p+'--------------\n')

w.close()
print('all files compiled')

          
          
          
     
