
#break 
for i in range(1,5): #from 0 to 4
     
     if i%3 ==0:
          break

     print(i)

#continue
for i in range(1,10): #from 0 to 4      
     if i%3 ==0:
          continue
     print(i)
     
#1 2 4 5 7 8      
     
     
