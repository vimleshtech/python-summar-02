
#function with default arguments
def add(a=0,b=0,c=0,d=0):
     
     print(a+b+c+d)


'''
def add(a,b,c):
     print(a+b+c)
     
'''
#function with dynamic argument
def mul(*arg): #argument type is tuple
     print(arg)
     print(type(arg))
     o = 1
     for x in arg:
          o *= x
     print(o)

#recurssive function
def rec(x):
     if x ==1:
          return x
     else:
          return x* rec(x-1)
     
     
#lambda function (single line function)
d= lambda x:x+1


d= lambda x:if x >100: 1 else 0

'''
def d(x):
     x =x+1
     return x
'''

      
     
add(11,323)
add(11,323,44)
add(11,323,55555,6666)

mul(111,222,33,4,4,4)
mul(111,222,33,4,4,4,55,34,33,4,4,5,6,5)

o = rec(6)
print(o)


print(d(10))
