class a:

     def add(s,a,b):
          print(a+b)



class b(a):
     def mul(s,x,y):
          print(x*y)

class c:
     def mul(s,x,y):
          print(x*y)


class x(b,c):
     def am(x):
          print()
          
o = b()
o.add(111,3)
o.mul(44,5)
