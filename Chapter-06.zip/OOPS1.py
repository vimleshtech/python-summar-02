class emp:

     def newemp(s):
          #print(s)
          s.eid = input('enter data :') #local variable  , now global
          s.ename = input('enter name :')
          

     def __del__(d):
          print(d,' is deleted ')
          
     def __init__(s,c=''):
          print(s,' object is created ',c)
          
          
     def show(a,sal):
          print(a.eid)
          print(a.ename)
          print(sal)
          
          

#object
o = emp('india')
print(o)
o.newemp()
o.show(22334)

#o.__del__()

del o

#o.show(44)

