
import mylib
mylib.add(11,2)


#or

import mylib as m
m.add(11,2)


#or
from mylib import * #all functions
add(11,22)

#or
from mylib import add,mul
add(11,22)





