
def add(a,b):
     print(a+b)

def mul(a,b):
     c =a*b
     return c
