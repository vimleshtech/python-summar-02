import socket               # Import socket module

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
#host = '192.169.1.2'

port = 1234                # Reserve a port for your service.

s.connect((host, port))
print (s.recv(64).decode())
s.close
