import os
import mysql.connector as c

src =r'C:\Users\vkumar15\Desktop\Desktop - Raman\Python-Batch-1stJun'
files = os.listdir(src)


con = c.connect(host='localhost',user='root',password='root',database='testdb')
cur = con.cursor()

for f in files:
     if f.endswith('.txt'):
          #print(f)
          o = open(src+'\\'+f)
          data = o.readlines()

          i =1
          for row in data:
               row = row.replace("'","''")
               st ="insert into file_data(ind,file,data) values("+str(i)+",'"+f+"','"+row+"')"
               #print(st)
               cur.execute(st)
               con.commit()
               i+=1
               
          
          o.close()
          
          

print('all files are uploaded')
