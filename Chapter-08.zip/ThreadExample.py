import time 
import threading

def task1():

     for i in range(1,5):
          print(i)
          #time.sleep(2)
     
def task2():     
     for i in range(11,15):
          print(i)
          #time.sleep(2)


p1 = threading.Thread(target=task1,name='Process1')
p2 = threading.Thread(target=task2,name='Process2')


p1.start()
p2.start()



#task1()
#task2()

