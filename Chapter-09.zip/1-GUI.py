from tkinter import *

f = Tk()
f.title('My First GUI App')

lbl = Label(text='Header')
lbl.pack()


lfn = Label(text='First Name')
lfn.pack()

tfn = Entry()
tfn.pack()


lln = Label(text='Last Name')
lln.pack()

tln = Entry()
tln.pack()

lblmsg = Label(text='')
lblmsg.pack()

def even_fun():
     fn =tfn.get()
     ln =tln.get()
     print('you have clicked on  save button')
     print('full name is ',fn+ln)
     lblmsg.configure(text=fn+ln)



     
     

btn = Button(text='Save',fg = "red",command=even_fun)
btn.pack()


f.mainloop()


