
from tkinter import *
import  tkinter.messagebox

window = Tk()
window.title('Test Title')
window.geometry("400x600") # size of the window width:- 500, height:- 375

Label(window, text = "Username").grid(row = 0) # this is placed in 0 0
# 'Entry' is used to display the input-field
Entry(window).grid(row = 0, column = 1) # this is placed in 0 1

Label(window, text = "Password").grid(row = 1) # this is placed in 1 0
Entry(window).grid(row = 1, column = 1) # this is placed in 1 1

# 'Checkbutton' is used to create the check buttons
Checkbutton(window, text = "Keep Me Logged In").grid(row=2,columnspan=2) # 'columnspan' tells to

Button(window,text='Sigin In').grid(row=0,column=3)

def lf(event):
     print('lf')
           
def mf(event):
     print('mf')


def rf(event):
     print('rf')
     

window.bind("<Button-1>", lf) #left
window.bind("<Button-2>", mf)  #middle
window.bind("<Button-3>", rf) #right 

# creating a root menu to insert all the sub menus
root_menu = Menu(window)
window.config(menu = root_menu)

def test():
     print('hi')
     tkinter.messagebox.showinfo("Alert Message", "This is just a alert message!")
     
     

# creating sub menus in the root menu
file_menu = Menu(root_menu) # it intializes a new su menu in the root menu
root_menu.add_cascade(label = "File", menu = file_menu) # it creates the name of the sub menu

file_menu.add_command(label = "New file....." , command = test) # it adds a option to the sub menu 'command' parameter is used to do some action
file_menu.add_command(label = "Open files")
file_menu.add_separator() # it adds a line after the 'Open files' option
file_menu.add_command(label = "Exit")



window.mainloop()

