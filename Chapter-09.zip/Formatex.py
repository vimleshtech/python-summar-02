

a =11
b =44
c =a+b

print('sum of a and b is c ',c)
print('sum of ',a,' and ',b,' is c ',c)

print('sum of {} and {} is {} '.format(a,b,c))

print('sum of {1} and {0} is {2} '.format(a,b,c))



#global keyword
m =11
def b():
     global n
     n =11
     print(n)
     print(m)

b()
print(m)
print(n)


#####
a = [111,222,3433,454,555]
for i in a:
     print(i*2)

#compresive list
print([i*2 for i in a])


print([i for i in a if i%2 ==0 ])

d =[[111,222,333,444,44],[44,555,555,34333]]
print([x for i in d for x in i if x%2 ==0 ])









     





