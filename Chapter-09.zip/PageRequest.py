import requests
from bs4  import BeautifulSoup



page = requests.get("https://www.google.com/search?source=hp&ei=FigHXaqvNIWy9QPzsoioCg&q=latest+news&oq=latest+&gs_l=psy-ab.3.0.0j0i131j0j0i131j0j0i131j0l2j0i131l2.16560.19497..20491...0.0..0.415.2388.0j1j5j0j2......0....1..gws-wiz.....0.-X_sxD_VbQ8")

print(page.status_code)
#print(page.content)


soup = BeautifulSoup(page.content, 'html.parser')

o = soup.find_all('a')
for c in o:
     print(c.get_text())
     




