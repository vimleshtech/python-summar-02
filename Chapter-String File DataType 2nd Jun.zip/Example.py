
"""
print('hi')
print('test')
"""


a =1
b =2
c =a+b

print(c)



a ='ssjgsfsgfsg $$%%%%% 1'
b ='2'
c =a+b

print(c)

