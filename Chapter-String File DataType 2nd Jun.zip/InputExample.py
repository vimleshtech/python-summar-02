#input from console
a = input('enter data :')
b = input('enter data :')

print(type(a))
print(type(b))
#c = a*b

#type casting / conversion
a = int(a)
b = int(b)

c = a*b
print(c)


