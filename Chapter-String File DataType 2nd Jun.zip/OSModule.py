import os

d= os.listdir(r'C:\Users\vkumar15\Desktop\Desktop - Raman')
#print(d)

#loop
#range(10) : # from 0 to 9
#range(0,10) : # from 0 to 9
#range(0,10,1) : # from 0 to 9

#f =d
tc = 0

for f in d:
     #print(f)
     if f.endswith('.txt'):
          tc+=1 #tc = tc+1
          #tc++ , tc--  : will not allow 
          
     

#count
print('count ',len(d))
print('text file count ',tc)      


     

     
     



