a =open(r'C:\Users\vkumar15\Desktop\mycode\mycode\Notes for Master Data Automation.txt')


data =a.readlines()

print(data[0])
print(data[1])

#print(data)
#word count
wc = 0
for r in data:
     print(r)
     w = r.split()
     wc +=len(w)
     

#row count
print(len(data))
print(wc)
     

