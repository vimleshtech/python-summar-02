
class student:

     def get_input(self):
          self.rno = int(input('enter roll no :'))
          self.name = input('enter name :')
          self.add = input('enter address :')
          self.city = input('enter city :')
          self.country = input('enter country :')


     def roll_no(self):
          return self.rno

     def disp(self):
          print('roll no :',self.rno)
          print('name :',self.name)
          print('address :',self.add)
          print('city :',self.city)
          print('country :',self.country)


#
o = []
for i in range(3):
     obj = student()
     obj.get_input()
     o.append(obj)

#sorting
for i in range(0,len(o)):
     for j in range(i+1,len(o)):
          if o[i].roll_no() > o[j].roll_no() :
               t = o[i]
               o[i] =o[j]
               o[j] = t
               

#show all
for x in o:
     x.disp()

#search
rno = int(input('enter roll no:'))
for x in o:
     if x.roll_no()   == rno:
          x.disp()


          

     
     


