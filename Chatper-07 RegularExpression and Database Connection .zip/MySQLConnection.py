import mysql.connector as c

#establish the connection 
con = c.connect(host='localhost',user='root',password='root',database='pythondb')
#print(con)
#create object of cursor class
cur = con.cursor()

def read_data():
     cur.execute('select * from users')

     out = cur.fetchall()

     #print(out)
     for r in out:
          #print(r)
          print(r[1],r[2])
     

def write_data():
     i = input('enter id :')
     name = input('enter name :')
     email = input('enter enail :')
     
     #cur.execute("insert into users(uid,name,email) values(100,'Monika','monika@gmail.com')")
     #"+i+"
     cur.execute("insert into users(uid,name,email) values("+i+",'"+name+"','"+email+"')")
     
     
     con.commit()
     print('data is saved')

write_data()
read_data()










     







     



