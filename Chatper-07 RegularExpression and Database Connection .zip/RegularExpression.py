import re


s = input('enter some string :')


o = re.match('(.*) are (.*)',s)
#print(o.groups())
#print(o.group(1))
#print(o.group(2))

print(o)

if o:
     print('are is matched')
else:
     print('are is not matched')


#search
email = input('enter email id :')
o = re.search('@gmail.com$',email)

o = re.search('^a.*@gmail.com$',email)

if o:
     print('valid email id')
else:
     print('invalid email id ')
     




