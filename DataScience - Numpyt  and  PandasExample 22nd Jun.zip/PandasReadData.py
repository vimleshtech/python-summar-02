import pandas as p
#from csv
df = p.read_csv(r'C:\Users\vkumar15\Desktop\Desktop - Training\Weekend\Saturday\Hadoop Project Data\SalesJan2009.csv')
print(df)


#from excel
df = p.read_excel(r'C:\Users\vkumar15\Desktop\Desktop - Training\Weekend\Saturday\Hadoop Project Data\Book1.xlsx',sheet_name='Sheet2')

print(df)


#from web url
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = p.read_csv(url, names=cols)
print(dataset)






