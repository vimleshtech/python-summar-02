import numpy as np

#to genderate the seq number/range
a = np.arange(1,20)
print(a)

#
a = np.arange(1,20,.5)
print(a)


#shape
print(a.shape)

#convert list to array
l = [111,2222,3434,555,666,433,333]
a = np.array(l)
print(a)


#multiple dimenssion array
l1 = [[1,2,4],[5,6,7],[7,8,9]]
l1 = np.array(l1)
l2 = l1*2

print(l1)
print(l2)

#array operation
print(np.add(l1,l2))



#array operation
print(np.subtract(l1,l2))


#array operation
print(np.multiply(l1,l2))



print(l1.shape)
#array transpose #conert row to column
print(l1.T) 



#
print(np.zeros(10))
print(np.ones(10))



#datatype
x =[111,222,333,4445]
a = np.array(x,dtype=float)
print(a)

#float, int64, object(string)










