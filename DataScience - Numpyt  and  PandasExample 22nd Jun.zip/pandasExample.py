import pandas as pd

#create blank or empty dataframe
df = pd.DataFrame()
print(df)


#create dataframe from list
emp  = {'eid':[1,2,30,50,4],
        'name':['Raman','Jatin','Divya','Ayush','Monika'],
        'gender':['Male','Male','Female','Male','Female'],
        'exp':[3,2,6,10,4],
        'salary':[31000,26000,72000,120000,49000],
        'country':['UK','US','UK','India','India']        
        }


df = pd.DataFrame(emp)
print(df)

#show info
print(df.info())

#show columns
print(df.columns)

#print shape
print(df.shape)

#show data from top
print(df.head(3))


#show from buttom
print(df.tail(3))


#show selected columns
print(df['name']) #show name
print(df[['name','salary']]) #show multiple column

#rename the column
df.columns =['emp code','ename','sex', 'exp','basicsal','country']
print(df)


#sort the data
print(df.sort_values('basicsal',ascending=True))
print(df.sort_values('basicsal',ascending=False))



#distribuation to data data / group by/summary the data
print(df.groupby('country').size())

print(df.groupby('country').max())
print(df.groupby('country').min())
print(df.groupby('country').sum())


print(df.groupby('country').sum()[['basicsal','exp']])


#convert dataframe list
data = df.values
print(data)

#all rows and selected columns
print(data[:,1:3]) #row,col

#selected rows and all coluns
print(data[2:5,:]) #row,col

#show selected rows and selected columns
print(data[2:5,1:5]) #row,col





###where 
out = df[df['basicsal']<100000]
print(out)


out = df[df['basicsal']>50000]
print(out)



out = df[df['sex']=='Male']
print(out)


### stats
print(df.describe())

out =df.describe()
#out.to_csv('stats.csv')
print('data is stored')


##correation
'''
How every variable is co-realated with other
Co-relation output:
-1 to +1
-1: neg co-relation
+1: pos co-relation
0: no corelation
'''
out = df[['exp','basicsal']]

print(df[['exp','basicsal']].corr())























     














