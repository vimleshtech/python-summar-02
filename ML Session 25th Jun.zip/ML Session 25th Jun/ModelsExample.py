import pandas

from pandas.tools.plotting import scatter_matrix
import matplotlib.pyplot as plt

from sklearn import model_selection #split 

from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix			
from sklearn.metrics import accuracy_score #
			
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC


src =r'C:\Users\vkumar15\Desktop\ML Session 25th Jun\iris.data'
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pandas.read_csv(src,names=cols)
print(dataset.shape)
print(dataset.head()) #default 5 rows from top


print(dataset.info()) #datatype , and is_null?

####
print(dataset.describe())
'''
          sepal-length  sepal-width  petal-length  petal-width
mean       5.843333     3.054000      3.758667     1.198667
std        0.828066     0.433594      1.764420     0.763161
min        4.300000     2.000000      1.000000     0.100000
max        7.900000     4.400000      6.900000     2.500000
'''

#print(dataset.corr())

#distribuation or group by
print(dataset.groupby('class').count())
'''
class  speal-len.   petal-length 
a      50             49
b 60
c 40
'''




print(dataset.groupby('class').size())
'''
a 50 
b 60
c 40
'''
print(dataset.groupby('class').min())
print(dataset.groupby('class').max())
print(dataset.groupby('class').sum()[['sepal-length', 'sepal-width']])
print(dataset.groupby('class').sum()[['petal-length', 'petal-width']])


#line chart 
#dataset.plot()
#plt.show()

#bar chart
#dataset.plot(kind='bar')
#plt.show()

#dataset.plot(kind='box')
#plt.show()


#dataset.hist()
#plt.show()

# scatter plot matrix
#scatter_matrix(dataset)
#plt.show()

array = dataset.values #convert to list
print(array)
x = array[:,0:4]
y = array[:,4]


print(x)
print(y)

#70:30
#80:20
#75:25

X_train, X_validation, Y_train, Y_validation =model_selection.train_test_split(x, y, test_size=.20, random_state=7)

print(X_train)
print(X_validation)

print(len(Y_train))
print(len(Y_validation))


#
'''
	-	Logistic Regression (LR)
	-	Linear Discriminant Analysis (LDA)
	-	K-Nearest Neighbors (KNN).
	-	Classification and Regression Trees (CART).
	-	Gaussian Naive Bayes (NB).
	-	Support Vector Machines (SVM).


'''


model = []
model.append(LogisticRegression())
model.append(DecisionTreeClassifier())
model.append(KNeighborsClassifier())
model.append(LinearDiscriminantAnalysis())
model.append(GaussianNB())

model.append(SVC())

print(model)
results=[]
for m in model:
     kfold = model_selection.KFold(n_splits=10, random_state=7)
     cv_results = model_selection.cross_val_score(m, X_train,Y_train,cv=kfold,scoring='accuracy')
     #results.append(cv_results)
     #msg = "%f (%f)" % ( cv_results.mean(), cv_results.std())
     #print(msg)
     results.append([cv_results.mean(),cv_results.std()])
     
     


print(results)

	
     

















































