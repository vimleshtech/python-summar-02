import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
#LinearRegression : is inbuilt class
from tkinter import *


window = Tk()

#Score/markr prediction
hours = [4,6,8,3,10,12,6,7]  #x
marks = [45,72,36,87,95,73,61,73]#y

#Any model  will not support/allow/work with list value
#convert list to array
#x must be two dimenssional array
hours = np.array(hours).reshape(-1,1) #(-1 :,1 : no of cols)
marks = np.array(marks)
print(hours)
print(marks)


model = LinearRegression()
model.fit(hours,marks) #get calculate the intercept, co-efficeint
print(model)

print(model.intercept_)
s = model.score(hours,marks)
print(s)


###predcition
#model.predict()

lbl = Label(text="enter hours ")
lbl.pack()

txt = Entry()
txt.pack()

msg = Label(text='')
msg.pack()

def predict():
     nhour = int(txt.get())
     p = model.predict([[nhour]])
     print(p)
     p = str(p)
     msg.configure(text='Predicted Mark :'+p)
     
     

     
btn = Button(text='Predict - Marks',command=predict)
btn.pack()

window.mainloop()
















