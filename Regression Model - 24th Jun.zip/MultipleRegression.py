import pandas as pd
from sklearn.linear_model import LinearRegression

src =r'C:\Users\vkumar15\Desktop\Desktop - Training\Weekend\Sunday\mtcars.csv'
cars = pd.read_csv(src)
print(cars)
print(cars.shape)


print(cars.corr())
o =cars.corr()
#o.to_csv('corr.csv')


print(cars.columns)
#'mpg', 'cyl', 'disp', 'hp'
x = cars[['cyl','disp','hp','wt']]
y = cars['mpg']

print(x)
print(y)

mreg  = LinearRegression()
mreg.fit(x,y)

print(mreg)
print(mreg.intercept_)

s = mreg.score(x,y)
print(s)


###
cyl= float(input('enter cyl'))
disp=float(input('enter disp'))
hp=float(input('enter hp'))
wt=float(input('enter wt'))

res = mreg.predict([[cyl,disp,hp,wt]])
print(res)











