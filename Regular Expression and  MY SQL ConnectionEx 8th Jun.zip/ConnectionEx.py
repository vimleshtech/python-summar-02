#mysql server connection example
import mysql.connector

#establish the connection 
con = mysql.connector.connect(host='127.0.0.1',user='root',password='root',database='learningapp')


#create object of cussor which can execute sql command or statement
cur = con.cursor()


##read from sql 
cur.execute('select * from users')
out  = cur.fetchall()
#print(out)

for r in out:
     #print(r)
     print(r[0], r[2])
     
###
#write     
cur.execute("insert into users(uid,name,email) values(100,'rohit','rohit@gmail.com')")
con.commit() #transaction commit
print('data is saved to db ')












