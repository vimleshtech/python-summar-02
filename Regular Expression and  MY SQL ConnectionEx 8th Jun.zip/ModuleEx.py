import re


s ='skjsgsfg113455$##%%%djs$$'

o = re.findall('\d',s)
print(o)

o = re.findall('\w',s)
print(o)


#
s =input('enter string to match ')

out = re.match('(.*) is (.*) abd (.*)',s)
#print(out.groups())
#print(out.group(1))

if out: #if is and abd match
     print('is and abd both are present in given string')
else:
     print('condition is not match')
     


#email validation
email = input('enter email id :')
o = re.search('@gmail.com$',email)
if o:
     print('valid gamil email id')
else:
     print('invalid gamil email id')



     





     





     
     



