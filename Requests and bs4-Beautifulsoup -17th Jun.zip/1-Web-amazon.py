import requests
from bs4 import BeautifulSoup

page = requests.get('http://www.yahoo.com/')
print(page)

print(page.url)
print(page.status_code)

page =page.content

out = BeautifulSoup(page,'html.parser')
match=  out.find_all('a')

print(len(match))

#write to file
file = open('web-date.txt','a')

for we in match:
     
     print(we.get('href'))
     #print(we.getText())
     #file.write(we.getText()+'\n')
     if we.get('href')[:4] =='http':
          req = requests.get('http://www.yahoo.com/')
          if req.status_code != 200:
               file.write('url is not correct :'+we.getText()+'\n')
               
               
     

file.close()

     
     
     


     






