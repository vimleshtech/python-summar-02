import requests
from bs4 import BeautifulSoup

#'https://www.amazon.com/s?k=iphone&ref=nb_sb_noss_2'

page = requests.get("http://erp.techvisionit.com/")
print(page)

print(page.url)
print(page.status_code)
print(page.cookies)
#print(page.text)
#print(page.content)

page =page.content

out = BeautifulSoup(page,'html.parser')
match=  out.find_all('input')

print(len(match))


for we in match:
     #print(we.get_text)
     print(we.get('id'))
     print(we.get('name'))
     print(we.get('type'))
     print(we.get('value'))
     
     
     


     






