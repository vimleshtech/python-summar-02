import requests
from bs4 import BeautifulSoup
import re

page = requests.get('https://web.archive.org/web/20121007172955/http://www.nga.gov/collection/anZ1.htm')

page =page.content

out = BeautifulSoup(page,'html.parser')
match=  out.find_all('table')

print(len(match))
print(match[0])


#write to file
file = open('web-date.txt','a')



for we in match:
     el = we.find_all('tr')
     print(el.getText())
     
     
                  
file.close()


##

#celan
file = open('web-data.txt')
rows = file.readlines()

newd = []
for r in range(0,len(rows)):

     o = re.match('(.*), (.*)',rows[r])
     
     if o:
          
          #print(rows[r])
          newd.append(rows[r])


for r in newd:
     print(r)
     




     
     
     


     






